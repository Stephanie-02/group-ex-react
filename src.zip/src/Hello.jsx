import React from 'react';

export class Hello extends React.Component {
    render () {
        return <h1>Hello</h1>
    }
}