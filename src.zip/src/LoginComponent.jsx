export default function LoginComponent ({visible, setLoggedIn}) {
    return (
        <div className={visible ? "" : "hidden"}>
            <input type="text"></input>
            <button>Log In</button>
        </div>
    )
}